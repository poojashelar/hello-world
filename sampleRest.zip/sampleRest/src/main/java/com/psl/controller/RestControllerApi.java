package com.psl.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;








import javax.servlet.http.HttpServletResponse;

import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.mvc.support.RedirectAttributesModelMap;
import org.springframework.web.servlet.support.RequestContextUtils;

import com.psl.java.Employee;
//http://localhost:8080/SpringRestApi/employees
@RestController
public class RestControllerApi {
	
	List<Employee> emplist;
	public RestControllerApi(){
		 emplist=new ArrayList<Employee>();
		createEmployeeList(emplist);
	}
	
	//http://localhost:8080/sampleRest/employees
	@RequestMapping(value = "/employees", method = RequestMethod.GET,headers="Accept=application/json")
	public List<Employee> getEmployees()
	{
		return emplist;
	}

	//http://localhost:8080/SpringRestApi/employee/23
	@RequestMapping(value = "/employee/{id}", method = RequestMethod.GET,headers="Accept=application/json")
	public Employee getEmployeeById(@PathVariable int id)
	{
		for (Employee employee: emplist) {
			if(employee.getId()==id)
				return employee;
		}
		
		return null;
	}

	public List<Employee> getAllEmp(){
		return emplist;
	}
	
	
	public List<Employee> createEmployeeList(List<Employee> emplist)
	{
		Employee e1=new Employee(23, "pooja");
		Employee e2=new Employee(24, "poonam");
		Employee e3=new Employee(25, "nutan");
		
		emplist.add(e1);
		emplist.add(e2);
		emplist.add(e3);
		return emplist;
	}
	
	
	//http://localhost:8080/sampleRest/updateval
	@RequestMapping(value = "/updateval", method = RequestMethod.GET)
	public ModelAndView employee(){
		ModelAndView mv=new ModelAndView("employeeform");
		mv.addObject("employee", new Employee());
		return mv ;
	}
	
	 @RequestMapping(value = "/updateRecord", method = RequestMethod.POST)
	   public ModelAndView addEmployee(@ModelAttribute Employee employee,BindingResult result, RedirectAttributes redirectAttrs,HttpServletResponse response) {
		 redirectAttrs.addAttribute("id", employee.getId()).addFlashAttribute("id", employee.getId());
		 redirectAttrs.addAttribute("name", employee.getName()).addFlashAttribute("name",  employee.getName()); 
	   
	      List<Employee> emplist=getEmployees();
	      for (Employee employee2 : emplist) {
	    	  if(employee2.getId()==employee.getId()){
	    		  
	    		  System.out.println("Previous Emp Name:"+employee2.getName());
	    	      System.out.println("Previous Emp id:"+employee2.getId());
	    	      
	    	      System.out.println("New Emp Name:"+employee.getName());
	    	      System.out.println("New Emp id:"+employee.getId());
	    		  employee2.setName(employee.getName());
	    		  System.out.println("updated");
	    		  System.out.println(getAllEmp());
	    		//  return "Employee details updated";
	    		  return new ModelAndView("redirect:/home.jsp");
	    		
	    	  }
			
		}
	     return new ModelAndView("redirect:/notFound.jsp");
	   }
}

	 
